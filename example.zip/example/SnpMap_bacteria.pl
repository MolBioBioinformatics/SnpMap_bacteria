#!/usr/bin/perl

$name = $ARGV[0];
$paired_end = $ARGV[1]; 
$ref_gnm = $ARGV[2]; 

$current_dir = `pwd`; chomp($current_dir);
$workdir = "$current_dir";
$fastq = "$current_dir/$name";

##############################################################################################################

#$ref_gnm = "/data/projects/Peter/genome/Pseudomonas_aeruginosa_ucbpp_pa14.fasta";

##############################################################################################################

$picrd_dir = "/path/picard-tools-1.100";
$gatk = "/path/GATK/GenomeAnalysisTK.jar";

$SnpSift = "/path/SnpSift.jar";
$SnpEff = "/path/snpEff.jar";
  
##############################################################################################################

### Mapping ### Step 1
if( $paired_end eq "paired-end" ){

$time = `date`; chomp $time;
print "$time\tMapping...\n";
`bwa aln -n 0.04 -o 1 -e -1 -d 16 -i 5 -l 1 -k 2 -M 3 -O 11 -E 4 $ref_gnm $fastq\_R1.fastq > $fastq\_R1.sai`;
`bwa aln -n 0.04 -o 1 -e -1 -d 16 -i 5 -l 1 -k 2 -M 3 -O 11 -E 4 $ref_gnm $fastq\_R2.fastq > $fastq\_R2.sai`;
`bwa sampe -n 3 -N 10 -a 500 -o 100000 $ref_gnm $fastq\_R1.sai $fastq\_R2.sai $fastq\_R1.fastq $fastq\_R2.fastq > $fastq.sam`;

$time = `date`; chomp $time;
print "$time\t Step 1 is DONE \n\n";

}

if ( $paired_end eq "single-end" ){

$time = `date`; chomp $time;
print "$time\tMapping...\n";
`bwa aln -n 0.04 -o 1 -e -1 -d 16 -i 5 -l 1 -k 2 -M 3 -O 11 -E 4 $ref_gnm $fastq\_R1.fastq > $fastq\_R1.sai`;
`bwa samse -n 3 $ref_gnm $fastq\_R1.sai $fastq\_R2.sai $fastq\_R1.fastq $fastq\_R2.fastq > $fastq.sam`;

$time = `date`; chomp $time;
print "$time\t Step 1 is DONE \n\n";

}
if ( ($paired_end ne "single-end") & ($paired_end ne "paired-end") ){ print "Please choose either paired-end or single-end as input\n"; exit; };


###  filter unmapped sam ### S2
`samtools view -b -F 4 -S -b $fastq.sam > $fastq.filter.bam`;
print "$time\t Step 2 is DONE \n\n";

### Add or Replace Groups ### S3
$time = `date`; chomp $time;
print "$time\tAdd or Replace Groups... Start Step 3 \n\n";

`java -Xmx2g -jar $picrd_dir/AddOrReplaceReadGroups.jar ID=1 SM=rgSM LB=rgLB PL=illumina PU=rgPU INPUT=$fastq.filter.bam OUTPUT=$fastq.AddOrReplaceReadGroups.filter.bam`;
`samtools sort $fastq.AddOrReplaceReadGroups.filter.bam -o $fastq.AddOrReplaceReadGroups.filter.sorted.bam`;
`samtools index $fastq.AddOrReplaceReadGroups.filter.sorted.bam`;

$time = `date`; chomp $time;
print "$time\t Step 3 is DONE \n\n";

### Realigner Target Creator/Indel Realigner ### Step 4
$time = `date`; chomp $time;
print "$time\tRealigner Target Creator/Indel Realigner... START Step 4 \n\n";

`java -Xmx2g -jar $gatk -T RealignerTargetCreator -I $fastq.AddOrReplaceReadGroups.filter.sorted.bam -R $ref_gnm -o $fastq.IndelRealigner.intervals`;
`java -Xmx2g -jar $gatk -T IndelRealigner -I $fastq.AddOrReplaceReadGroups.filter.sorted.bam -R $ref_gnm -targetIntervals $fastq.IndelRealigner.intervals -o $fastq.realignedBam.bam`;

$time = `date`; chomp $time;
print "$time\t Step 4 is DONE \n\n";

### Mark Duplicate ### Step 5
$time = `date`; chomp $time;
print "$time\tMark Duplicate...\n";
`java -Xmx2g -jar $picrd_dir/MarkDuplicates.jar REMOVE_DUPLICATES=true ASSUME_SORTED=true READ_NAME_REGEX='[a-zA-Z0-9]+.*:[0-9]:([0-9]+):([0-9]+):([0-9]+)\$' OPTICAL_DUPLICATE_PIXEL_DISTANCE=100 INPUT=$fastq.realignedBam.bam OUTPUT=$fastq.realignedBam.dedupped.bam M=$fastq.dupmetrics.dat`;

$time = `date`; chomp $time;
print "$time\t Step 5 is DONE \n\n";

### Unified Genotyper ### Step 6
$time = `date`; chomp $time;
print "$time\tUnified Genotyper...\n";
`samtools sort $fastq.realignedBam.dedupped.bam -o $fastq.realignedBam.dedupped.bam.sorted.bam`;
`samtools index $fastq.realignedBam.dedupped.bam.sorted.bam`;
`java -Xmx4g -jar $gatk -T UnifiedGenotyper -R $ref_gnm -I $fastq.realignedBam.dedupped.bam.sorted.bam -glm BOTH -stand_call_conf 30 -stand_emit_conf 30 -hets 0.001 -pcr_error 0.0001 -mbq 17 -deletions 0.05 -maxAltAlleles 5 -minIndelCnt 5 -indelHeterozygosity 0.000125 -indelGCP 10 -indelGOP 45 -o $fastq.UnifiedGenotyper.vcf`;

$time = `date`; chomp $time;
print "$time\t Step 6 is DONE \n\n";

### Create a BedGraph of genome coverage ### Step 7
$time = `date`; chomp $time;
print "$time\tBedGraph of genome coverage...\n";
`bedtools genomecov -ibam -scale -bga -i $fastq.realignedBam.dedupped.bam.sorted.bam -g $ref_gnm > $fastq.BedGraph`;

$time = `date`; chomp $time;
print "$time\t Step 7 is DONE \n\n";

### SnpSift Filter ### Step 8
$time = `date`; chomp $time;
print "$time\tSnpEff...\n";
`cat $fastq.UnifiedGenotyper.vcf | java -jar $SnpSift filter "isHom( GEN[0] ) & isVariant( GEN[0] )" > $fastq.S8.vcf`;
`grep -w 0\$ $fastq.BedGraph > $fastq.filtered.BedGraph`;

$time = `date`; chomp $time;
print "$time\t Step 8 is DONE \n\n";

### SnpEff ### Step 9
`java -Xmx4g -jar $SnpEff -c /data/cetinbas/snpEff/snpEff.config -no-downstream -no-intergenic -no-intron -no-upstream -i vcf -o vcf -upDownStreamLen 10000 -no None -s $fastq.snpEff_summary1.html Pseudomonas_aeruginosa_ucbpp_pa14 $fastq.S8.vcf > $fastq.final.vcf`;
`java -Xmx4g -jar $SnpEff -c /data/cetinbas/snpEff/snpEff.config -i bed -o bed -upDownStreamLen 10000 -no None -s $fastq.snpEff_summary2.html Pseudomonas_aeruginosa_ucbpp_pa14 $fastq.filtered.BedGraph > $fastq.final.bed`;

$time = `date`; chomp $time;
print "$time\tFinished!\n";

