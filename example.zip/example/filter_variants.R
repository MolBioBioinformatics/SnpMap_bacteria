
args = commandArgs(TRUE)

if (length(args)<2) {
  stop("Two input files 'sample.vcf' and 'control.vcf' are needed ! \n", call.=FALSE)
} 

sample_name=as.character(args[1])
control_name=as.character(args[2])

S1<-read.delim(sample_name,header = TRUE,skip = 39)
C1<-read.delim(control_name,header = TRUE,skip = 39) 

S1snp <- paste(S1$POS,S1$REF,S1$ALT,sep = ":"); rownames(S1)<-S1snp 
C1snp <- paste(C1$POS,C1$REF,C1$ALT,sep = ":"); rownames(C1)<-C1snp 

dif_S1 = setdiff(S1snp,C1snp) 

T1<-S1[dif_S1,]

write.table(T1,file="final_variants.vcf",sep="\t",row.names=FALSE, quote=FALSE)


